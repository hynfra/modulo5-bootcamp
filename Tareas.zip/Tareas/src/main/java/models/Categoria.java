package models;

public class Categoria {
  public int id;
  public String nombre;
  
  public Categoria(int id, String nombre) {
	super();
	this.id = id;
	this.nombre = nombre;
  }
  
  
}
