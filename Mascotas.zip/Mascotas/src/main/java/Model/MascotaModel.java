package Model;

public class MascotaModel {

}
